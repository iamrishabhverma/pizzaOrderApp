package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.view.View;
import android.widget.Toast;
//import android.view.View.OnClickListener;
import android.widget.RadioGroup;


public class MainActivity extends AppCompatActivity {

    RadioButton lar,med,sml;
    CheckBox ppr,ham,sau,beef,oni,tom,ched,parm,all,none;
    EditText amt,qty;
    Button finish;
    RadioGroup size;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lar = (RadioButton) findViewById(R.id.large);
        med = findViewById(R.id.medium);
        sml = findViewById(R.id.small);

        ppr = findViewById(R.id.pepperoni);
        ham = findViewById(R.id.ham);
        sau = findViewById(R.id.italianSausage);
        beef = findViewById(R.id.beefCrumble);
        oni = findViewById(R.id.onion);
        tom = findViewById(R.id.sunriseTomatoes);
        ched = findViewById(R.id.cheddarCheese);
        parm = findViewById(R.id.parm);
        all = findViewById(R.id.all);
        none = findViewById(R.id.none);
        qty = findViewById(R.id.qty);
        amt = findViewById(R.id.result);
        finish = findViewById(R.id.finishBtn);
        size = (RadioGroup) findViewById(R.id.sizeGroup);
       // top = findViewById(R.id.toppingsGroup);
        size = findViewById(R.id.sizeGroup);
      // Float fin = Float.parseFloat(fin.floatValue();


        finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double q,fin;

                if (lar.isChecked()){
                    if (ppr.isChecked()){
                        q =Double.parseDouble(qty.getText().toString());
                        fin =   12.99 * q ;
                        amt.setText("Total Bill: " + fin);
                    }
                    if (ham.isChecked()){
                        q =Double.parseDouble(qty.getText().toString());
                        fin =   12.99 * q ;
                        amt.setText("Total Bill: " + fin);
                    }
                    if (sau.isChecked()){
                        q =Double.parseDouble(qty.getText().toString());
                        fin =  2 + 12.99 * q ;
                        amt.setText("Total Bill: " + fin);
                    }
                    if (beef.isChecked()){
                        q =Double.parseDouble(qty.getText().toString());
                        fin =  2 + 12.99 * q ;
                        amt.setText("Total Bill: " + fin);
                    }
                    if (tom.isChecked()){
                        q =Double.parseDouble(qty.getText().toString());
                        fin =  2 + 12.99 * q ;
                        amt.setText("Total Bill: " + fin);
                    }
                    if (oni.isChecked()){
                        q =Double.parseDouble(qty.getText().toString());
                        fin =  2 + 12.99 * q ;
                        amt.setText("Total Bill: " + fin);
                    }
                    if (ched.isChecked()){
                        q =Double.parseDouble(qty.getText().toString());
                        fin =  2 + 12.99 * q ;
                        amt.setText("Total Bill: " + fin);
                    }
                    if (parm.isChecked()){
                        q =Double.parseDouble(qty.getText().toString());
                        fin =  2 + 12.99 * q ;
                        amt.setText("Total Bill: " + fin);
                    }
                    if (none.isChecked()){
                        q =Double.parseDouble(qty.getText().toString());
                        fin =   12.99 * q ;
                        amt.setText("Total Bill: " + fin);
                    }
                    if (all.isChecked()){
                        q =Double.parseDouble(qty.getText().toString());
                        fin =  12 + 12.99 * q ;
                        amt.setText("Total Bill: " + fin);
                    }

                }


                if (med.isChecked()){
                    if (ppr.isChecked()){
                        q =Double.parseDouble(qty.getText().toString());
                        fin =   7.99 * q ;
                        amt.setText("Total Bill: " + fin);
                    }
                    if (ham.isChecked()){
                        q =Double.parseDouble(qty.getText().toString());
                        fin =   7.99 * q ;
                        amt.setText("Total Bill: " + fin);
                    }
                    if (sau.isChecked()){
                        q =Double.parseDouble(qty.getText().toString());
                        fin =  2 + 7.99 * q ;
                        amt.setText("Total Bill: " + fin);
                    }
                    if (beef.isChecked()){
                        q =Double.parseDouble(qty.getText().toString());
                        fin =  2 + 7.99 * q ;
                        amt.setText("Total Bill: " + fin);
                    }
                    if (tom.isChecked()){
                        q =Double.parseDouble(qty.getText().toString());
                        fin =  2 + 7.99 * q ;
                        amt.setText("Total Bill: " + fin);
                    }
                    if (oni.isChecked()){
                        q =Double.parseDouble(qty.getText().toString());
                        fin =  2 + 7.99 * q ;
                        amt.setText("Total Bill: " + fin);
                    }
                    if (ched.isChecked()){
                        q =Double.parseDouble(qty.getText().toString());
                        fin =  2 + 7.99 * q ;
                        amt.setText("Total Bill: " + fin);
                    }
                    if (parm.isChecked()){
                        q =Double.parseDouble(qty.getText().toString());
                        fin =  2 + 7.99 * q ;
                        amt.setText("Total Bill: " + fin);
                    }
                    if (none.isChecked()){
                        q =Double.parseDouble(qty.getText().toString());
                        fin =   7.99 * q ;
                        amt.setText("Total Bill: " + fin);
                    }
                    if (all.isChecked()){
                        q =Double.parseDouble(qty.getText().toString());
                        fin =  12 + 7.99 * q ;
                        amt.setText("Total Bill: " + fin);
                    }

                }



                if (sml.isChecked()){
                    if (ppr.isChecked()){
                        q =Double.parseDouble(qty.getText().toString());
                        fin =   5.99 * q ;
                        amt.setText("Total Bill: " + fin);
                    }
                    if (ham.isChecked()){
                        q =Double.parseDouble(qty.getText().toString());
                        fin =   5.99 * q ;
                        amt.setText("Total Bill: " + fin);
                    }
                    if (sau.isChecked()){
                        q =Double.parseDouble(qty.getText().toString());
                        fin =  2 + 5.99 * q ;
                        amt.setText("Total Bill: " + fin);
                    }
                    if (beef.isChecked()){
                        q =Double.parseDouble(qty.getText().toString());
                        fin =  2 + 5.99 * q ;
                        amt.setText("Total Bill: " + fin);
                    }
                    if (tom.isChecked()){
                        q =Double.parseDouble(qty.getText().toString());
                        fin =  2 + 5.99 * q ;
                        amt.setText("Total Bill: " + fin);
                    }
                    if (oni.isChecked()){
                        q =Double.parseDouble(qty.getText().toString());
                        fin =  2 + 5.99 * q ;
                        amt.setText("Total Bill: " + fin);
                    }
                    if (ched.isChecked()){
                        q =Double.parseDouble(qty.getText().toString());
                        fin =  2 + 5.99 * q ;
                        amt.setText("Total Bill: " + fin);
                    }
                    if (parm.isChecked()){
                        q =Double.parseDouble(qty.getText().toString());
                        fin =  2 + 5.99 * q ;
                        amt.setText("Total Bill: " + fin);
                    }
                    if (none.isChecked()){
                        q =Double.parseDouble(qty.getText().toString());
                        fin =   5.99 * q ;
                        amt.setText("Total Bill: " + fin);
                    }
                    if (all.isChecked()){
                        q =Double.parseDouble(qty.getText().toString());
                        fin =  12 + 5.99 * q ;
                        amt.setText("Total Bill: " + fin);
                    }

                }

            }
        });
    }
}
